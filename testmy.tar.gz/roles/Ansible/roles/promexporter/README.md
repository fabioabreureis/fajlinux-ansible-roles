### Prometheus node exporter role
